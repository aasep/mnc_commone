<?php

	header('location: login');
	
?>