<div class="page-logo">
			<a href="index.php">
			<img src="images/logo-mnc-bank.png" alt="logo" style="height: 45px;" class="logo-default"/> 
			<!--<img src="images/logo-mnc-bank.png" style="height: 15px;" alt="logo"/> -->
			</a>
			<div class="menu-toggler sidebar-toggler">
			</div>
		</div>